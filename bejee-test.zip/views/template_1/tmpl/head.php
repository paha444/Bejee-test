<?php if (!defined('SITE')) exit('No direct script access allowed.'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
    
<title>Bejee-test</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />


<!-- Bootstrap core CSS -->
<link href="<?php echo $this->config['base_url'] ?>/views/<?php echo $this->config['template'] ?>/bootstrap-4.0.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Custom styles for this template -->
<link href="<?php echo $this->config['base_url'] ?>/views/<?php echo $this->config['template'] ?>/bootstrap-4.0.0/dist/css/album.css" rel="stylesheet">

</head>

