<?php if (!defined('SITE')) exit('No direct script access allowed.'); ?>




    <footer class="text-muted">
      <div class="container">
        <p class="float-right">
          <a href="#">Back to top</a>
        </p>
        <p>Album example is &copy; Bootstrap, but please download and customize it for yourself!</p>
        <p>New to Bootstrap? <a href="../../">Visit the homepage</a> or read our <a href="../../getting-started/">getting started guide</a>.</p>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="<?php echo $this->config['base_url'] ?>/views/<?php echo $this->config['template'] ?>/bootstrap-4.0.0/assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="<?php echo $this->config['base_url'] ?>/views/<?php echo $this->config['template'] ?>/bootstrap-4.0.0/assets/js/vendor/popper.min.js"></script>
    <script src="<?php echo $this->config['base_url'] ?>/views/<?php echo $this->config['template'] ?>/bootstrap-4.0.0/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo $this->config['base_url'] ?>/views/<?php echo $this->config['template'] ?>/bootstrap-4.0.0/assets/js/vendor/holder.min.js"></script>
  </body>
</html>